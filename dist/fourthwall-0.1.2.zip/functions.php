<?php
/**
 * Fourth Wall Events
 * WordPress Functions File
 */

include_once 'includes/functions/plugins.php';
?>
